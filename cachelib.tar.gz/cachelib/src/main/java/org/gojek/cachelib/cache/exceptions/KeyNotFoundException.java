/**
 * Alipay.com Inc. Copyright (c) 2004-2020 All Rights Reserved.
 */
package org.gojek.cachelib.cache.exceptions;

/**
 * @author paras.chawla
 * @version $Id: StorageFullException.java, v 0.1 2020-11-23 20:14 paras.chawla Exp $$
 */
public class KeyNotFoundException extends RuntimeException {
}