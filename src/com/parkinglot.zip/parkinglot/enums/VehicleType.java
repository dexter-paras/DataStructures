/**
 * Alipay.com Inc. Copyright (c) 2004-2021 All Rights Reserved.
 */
package com.parkinglot.enums;

/**
 * @author paras.chawla
 * @version $Id: VehicleType.java, v 0.1 2021-03-04 6:42 PM paras.chawla Exp $$
 */
public enum VehicleType {

    TWO_WHEELER,
    FOUR_WHEELER;
}